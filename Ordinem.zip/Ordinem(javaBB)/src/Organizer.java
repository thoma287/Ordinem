import java.util.Scanner;
public class Organizer {

    public static void OrgLogin(String username, String password){
        if (username.matches(username) && password.matches(password)) //Check inside database if it contains username/password
        {
            //open user account

        }


    }
}
