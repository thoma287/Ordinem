/**
 * Created by Stevenisdrew on 11/5/16.
 */
import java.util.Scanner;
public class Main {

public static void main(String[] args){




}
}

